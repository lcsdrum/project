package br.com.ifpe.belezamaster.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class BelezaMasterController {

	@RequestMapping("/olaMundoSpring")
	public String olaMundo() {
	System.out.println("Executando a lógica com Spring MVC.");
	return "olaMundo";
}
	@RequestMapping("/CadastrarProfissional")
	public String CadastrarProfissional() {
	System.out.println("Executando a lógica com Spring MVC.");
	return "IncluirCadastrarProfissional";	
}
}